# Smart Traffic Management System

Simple HTML/CSS/JavaScript demo.